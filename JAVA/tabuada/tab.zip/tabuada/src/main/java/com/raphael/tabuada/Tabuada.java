/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.raphael.tabuada;

/**
 *
 * @author Condoriano
 */
public class Tabuada {

    public static void main(String[] args) {

        System.out.println("Super Calculadora O.O. da Etec\n"
                         + "******************************\n");        
        Contas contas = new Contas();
        contas.menu();
        
        
    }
    }

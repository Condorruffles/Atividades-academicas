/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package medico;


import java.util.Scanner;

/**
 *
 * @author Raphael Mauricio
 */
public class Medico {

    public String getCMR() {
        return CMR;
    }

    public void setCMR(String CMR) {
        this.CMR = CMR;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public double getsalario() {
        return salario;
    }

    public void setsalario(double salario) {
        this.salario = salario;
    }
    public String getStatus() {
        return status;
    }

    public double getSalario() {
        return salario;
    }

    public int getOp() {
        return op;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }

    public void setOp(int op) {
        this.op = op;
    }
    
    private int op;
    private String CMR;
    private String nome;
    private String status;
    private String especialidade;
    private int idade;
    private double salario;
    private double salarioAp;
    
    public static void main(String[]args){
        
    	Medico med = new Medico();
        MedicoCirurgiao cirurgiao = new MedicoCirurgiao();
        MedicoAux aux = new MedicoAux();
    	
    	System.out.println("-------------------Vamos fazer seu cadastro de medico!-------------------");
    	System.out.println("Digite seu CMR: ");
    	Scanner scan = new Scanner(System.in);
    	med.CMR = scan.nextLine();
    	System.out.println("Digite seu nome: ");
    	med.nome = scan.nextLine();
    	System.out.println("Digite sua idade: ");
    	med.idade = scan.nextInt();
    	System.out.println("Digite seu salario: ");
    	med.salario = scan.nextDouble();
        
        System.out.println("Qual sua especialidade?: ");
        System.out.println("1 - Medico cirurgiao");
        System.out.println("2 - Medico Auxiliar");
        System.out.println("3 - Nao tenho especialidade");
        med.op = scan.nextInt();
        
        switch(med.op){
            case 1:
                med.status = cirurgiao.mudarStatus(med.idade);
                med.salarioAp = cirurgiao.valorAposentadoria(med.salario);
                med.especialidade = "Medico Cirurgiao";
                break;
            case 2:
                med.status = aux.mudarStatus(med.idade);
                med.salarioAp = valorAposentadoria(med.salario);
                med.especialidade = "Medico Auxiliar";
                break;
            case 3:
                med.status = mudarStatus(med.idade);
                med.salarioAp = valorAposentadoria(med.salario);
                med.especialidade = "";
                break;
        }
        
    	scan.close();
    	
    	System.out.println("-------------------Aqui estao suas informacoes-------------------");
    	System.out.println("CMR: "+ med.CMR);
    	System.out.println("Nome: "+ med.nome);
        if(((med.especialidade).equalsIgnoreCase("Medico Cirurgiao"))|| (med.especialidade).equalsIgnoreCase("Medico Auxiliar")) {
    	System.out.println("Especialidade: "+ med.especialidade);
    	}
    	System.out.println("Status: "+ med.status);
    	System.out.println("Idade: "+ med.idade);
    	if((med.status).equalsIgnoreCase("Aposentado")) {
    		System.out.println("Salario: "+ med.salarioAp + " (Aposentadoria)");
    		System.out.println("Salario base: "+ med.salario + "(Quando em atividade)");
    	}else{
            System.out.println("Salario: "+ med.salario);
        }
    }
    
    public static String mudarStatus(int a){
        String b;
      if(a > 55){
          b = "Aposentado";
      }else{
          b = "Em atividade";
      }
        return b;
    }
    public static double valorAposentadoria(double a){
          double c = (a/10)*8;
        return c;
    }
}

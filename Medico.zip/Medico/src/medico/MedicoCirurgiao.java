/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package medico;

/**
 *
 * @author laboratorio.software
 */
public class MedicoCirurgiao extends Medico{
     public static String mudarStatus(int a){
        String b;
      if(a > 50){
          b = "Aposentado";
      }else{
          b = "Em atividade";
      }
        return b;
    }
    public static double valorAposentadoria(double a){
          double c = ((a/10)*8) + 800;
        return c;
    }
    
}

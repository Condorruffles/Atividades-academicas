/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package medico;

/**
 *
 * @author laboratorio.software
 */
public class MedicoAux extends Medico{
    public static String mudarStatus(int a){
        String b;
      if(a > 60){
          b = "Aposentado";
      }else{
          b = "Em atividade";
      }
        return b;
    }
}
